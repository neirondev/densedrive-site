DenseDrive — sample files for App Review

These files are generated sample data. They are not a real project and contain
no personal or third-party content. They exist for one purpose: to give App
Review something compressible to put into a DenseDrive disk.

How to use them

1. In DenseDrive, create a disk of any size (for example 5 GB).
2. When it mounts in Finder, copy this whole folder into it.
3. Look at the app's list: it shows how much data went in versus how much
   space is actually used on disk.

What to expect

This folder is source code, logs, JSON, CSV and Markdown — the kind of data the
app is built for. It should compress roughly three to four times.

Media does not compress. If you copy video, photos or music instead, the ratio
will be about 1.0, and that is the correct result, not a bug. The app's own
listing says so plainly.
